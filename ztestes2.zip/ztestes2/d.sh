 #!/bin/bash          
clear && make && ./sintatico.out <b.txt >saida.txt 
