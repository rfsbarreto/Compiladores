 #!/bin/bash          
clear && make && ./sintatico.out <yes/semyes.monga >saida.txt 
